﻿namespace Lab1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var animalsFeedingFactory = new AnimalsFeeding();
            Animal cat = animalsFeedingFactory.AddCat(10, 2, "Meow", "Andrii");

            Animal dog = animalsFeedingFactory.AddDog(15, 3, "GoodBoy", "Andrii");

            animalsFeedingFactory.Feed(5, cat);
            animalsFeedingFactory.Feed(15, dog);
        }
    }
}