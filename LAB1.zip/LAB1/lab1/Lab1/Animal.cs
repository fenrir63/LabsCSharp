namespace Lab1
{
    public abstract class Animal
    {
        
        protected int Age;            
        protected string Alias;
        protected int CountOfFood;
        protected string OwnerName;

        protected Animal(int countOfFood, int age, string alias, string ownerName)
        {
            CountOfFood = countOfFood;
            Age = age;
            Alias = alias;
            OwnerName = ownerName;
        }

        public abstract void Feed(int count);
    }
}