using System;

namespace Lab1
{
    public class Cat : Animal
    {
        public Cat(int countOfFood,
            int age,
            string alias,
            string nameOfOwner)
            : base(countOfFood,
                age,
                alias,
                nameOfOwner)
        {
        }

        public override void Feed(int count)
        {
            if (count == CountOfFood)
            {
                Console.Write("The pet " +
                              Alias +
                              " is no longer hungry and loves his master " +
                              OwnerName +
                              " <3\n");
            }
            else
            {
                if (count < CountOfFood)
                    Console.Write("The pet " +
                                  Alias +
                                  " is still hungry and asks his master " +
                                  OwnerName +
                                  " to feed him more :(\n");
                else
                    Console.Write("The pet " +
                                  Alias +
                                  " is no longer hungry, but asks his master " +
                                  OwnerName +
                                  " to feed him less :)\n");
            }
        }
    }
}