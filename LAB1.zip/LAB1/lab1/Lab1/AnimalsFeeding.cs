namespace Lab1
{
    public class AnimalsFeeding
    {
        public Dog AddDog(int countOfFood, int age, string alias, string nameOfOwner)
        {
            var dog = new Dog(countOfFood, age, alias, nameOfOwner);
            return dog;
        }

        public Cat AddCat(int countOfFood, int age, string alias, string nameOfOwner)
        {
            var cat = new Cat(countOfFood, age, alias, nameOfOwner);
            return cat;
        }

        public void Feed(int countOfFood, Animal animal)
        {
            animal.Feed(countOfFood);
        }
    }
}